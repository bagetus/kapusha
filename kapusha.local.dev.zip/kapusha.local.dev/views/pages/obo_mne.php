<div align="center" style="font-family: Helvetica; line-height: 1.5; font-size: 30px;">

Работу выполнил<br />
студент 3 курса<br />
<strong><em>Учебно-научного института информационных и коммуникационных технологий</em></strong><br />
группы КН-12<br />
<strong>Зырянов Вячеслав</strong><br />

</div>
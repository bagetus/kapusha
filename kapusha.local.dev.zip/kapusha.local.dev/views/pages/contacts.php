<span style="margin-left: 50px; font-size: 30px; font-family: Helvetica;">Карта проезда</span>

<table border="0" width="100%">

<tr><td>
<div align="left" style="margin: 20px 0px 0px 50px;">
<script type="text/javascript" charset="utf-8" src="//api-maps.yandex.ru/services/constructor/1.0/js/?sid=cnHmX-gR2bz6Tq7tcTXvBpt5OfoDkk_F&width=700&height=450"></script>
</div>
</td>

<td style="width: 750; margin-right: 50px; vertical-align: top; line-height: 1.5;">
<div style="margin-left: 20px; margin-top: 12px;">
<span style="margin-left: 10px; font-size: 20px; font-family: Helvetica;">Телефоны</span><br />
<span style="margin-left: 10px; font-size: 15px; font-family: Helvetica;">(000) 000-00-00</span><br />
<span style="margin-left: 10px; font-size: 15px; font-family: Helvetica;">(333) 333-33-33</span><br />
<span style="margin-left: 10px; font-size: 15px; font-family: Helvetica;">(222) 222-22-22</span><br /><br />

<span style="margin-left: 10px; font-size: 20px; font-family: Helvetica;">График работы</span><br />
<span style="margin-left: 10px; font-size: 15px; font-family: Helvetica;">Пн-Пт: с 8:00 до 21:00</span><br />
<span style="margin-left: 10px; font-size: 15px; font-family: Helvetica;">Суббота: с 9:00 до 20:00</span><br />
<span style="margin-left: 10px; font-size: 15px; font-family: Helvetica;">Воскресенье: с 10:00 до 19:00</span><br /><br />

<span style="margin-left: 10px; font-size: 20px; font-family: Helvetica;">Адрес</span><br />
<span style="margin-left: 10px; font-size: 15px; font-family: Helvetica;">Украина, г. Киев, ул. Лагерная 30-32, оф.№1</span><br />

</div>
</td></tr>

</table>
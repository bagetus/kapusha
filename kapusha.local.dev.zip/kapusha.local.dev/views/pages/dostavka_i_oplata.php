<div style="text-align: left; margin-left: 50px; line-height: 1.5; width: 1100px;">

<div style="margin-left: 10px; font-size: 30px; font-family: Helvetica; font-weight: bold;">Доставка</div><br />

<div style="margin-left: 10px; font-size: 20px; font-family: Helvetica;">Службой доставки "Новая Почта"</div>

<div style="margin-left: 10px; font-size: 12px; font-family: Helvetica;">
Свой заказ Вы получите в офисе перевозчика в Вашем или близлежащем городе. Стоимость доставки составляет 40 грн. При заказе товара на сумму более 1000 грн - доставка для Вас будет бесплатной.
</div><br />

<div style="margin-left: 10px; font-size: 20px; font-family: Helvetica;">Курьером в пределах города</div>

<div style="margin-left: 10px; font-size: 12px; font-family: Helvetica;">
Эта услуга доступна только для жителей городов: Киев, Днепропетровск, Донецк. Доставка осуществляется с 10 до 18 часов в рабочие дни. Стоимость курьерской доставки по городу составляет 40 грн. При заказе товара на сумму более 1000 грн - доставка курьером по указанному Вами адресу осуществляется бесплатно. 
</div><br />

<div style="margin-left: 10px; font-size: 20px; font-family: Helvetica;">Самовывоз</div>

<div style="margin-left: 10px; font-size: 12px; font-family: Helvetica;">
Вы можете получить свой заказ самостоятельно в одном из наших магазинов в г. Киев, Днепропетровск и Донецк. В этом случае Вы можете не только оплатить товар на месте, но и вместе с проверкой работоспособности техники получить консультации по пользованию ею от квалифицированных продавцов-консультантов.
</div><br />

<div style="margin-left: 10px; font-size: 20px; font-family: Helvetica;">Междугородной службой доставки</div>

<div style="margin-left: 10px; font-size: 12px; font-family: Helvetica;">
Для жителей других городов доставка осуществляется службой доставки "Новая почта" или другой по согласованию с покупателем. Если сумма покупки составляeт менее 1000 грн., то стоимость доставки добавляется к сумме заказа при его оформлении на сайте. При заказе товара на сумму более 1000 грн — доставка бесплатна. ОПЛАТА ПРИНИМАЕТСЯ ТОЛЬКО В НАЦИОНАЛЬНОЙ ВАЛЮТЕ. Срок доставки в областные города 1-2, во все остальные 2-3 дня.
<img style="float: right; margin-top: 45px;" src="/images/dostavka.jpg"/>
</div><br />

<div style="margin-left: 10px; font-size: 30px; font-family: Helvetica; font-weight: bold;">Оплата</div>

<div style="margin-left: 10px; font-size: 20px; font-family: Helvetica;">Оплата наличными курьеру</div>

<div style="margin-left: 10px; font-size: 12px; font-family: Helvetica;">
Вы можете заказать доставку товара к Вам домой или в офис и оплатить товар наличными курьеру по факту доставки. ОПЛАТА ПРИНИМАЕТСЯ ТОЛЬКО В НАЦИОНАЛЬНОЙ ВАЛЮТЕ. (При заказе на сумму свыше 1000 грн. доставка товара не оплачивается).

</div><br />



</div>
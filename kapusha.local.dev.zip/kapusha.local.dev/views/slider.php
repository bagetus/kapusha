  <div id="container" class="cf">

	<div id="main" role="main">
      <section class="slider">
        <div class="flexslider">
          <ul class="slides">
                <li>
  	    	    <img src="images/1.png" />
  	    		</li>
  	    		<li>
  	    	    <img src="images/2.png" />
              </li>
  	    		<li>
  	    	    <img src="images/3.png" />
  	    		</li>
            <li>
              <img src="images/4.png" />
            </li>
            <li>
              <img src="images/5.png" />
            </li>
          </ul>
        </div>
      </section>
    </div>
  
  </div>

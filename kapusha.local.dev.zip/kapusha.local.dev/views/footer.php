<div class="footer">

<div style="margin: 20px;">
© Интернет-магазин бас-гитар «Капуша»<br />
<div style="text-align: right; margin-top: -20px;">
<a href="index.php?view=dostavka_i_oplata">Доставка и оплата</a><br />
<a href="index.php?view=contacts">Контакты</a><br />

</div>
</div>

</div>

<?php
header("Location: main_login.php");
?>
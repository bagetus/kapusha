<div align="center" style="margin: 20px;">

<table border="2" style="border-collapse: collapse; text-align: center;" width = "400px">
<tr>
	
	<td><a href="m_products.php"><img src ="images/prod.png"></a></td>
	<td><a href="m_orders.php"><img src ="images/ord.png"></a></td>
	<td><a href="http://sql33.hostinger.com.ua/phpmyadmin/index.php?db=u745861867_bd&token=316774a95ea556bc64cf7d398dd6aa83"><img src="images/db.png"></a></td>
</tr>
<tr>
<td><a href="m_products.php">Товары</a></td>
<td><a href="m_orders.php">Заказы</a></td>
<td><a href="http://sql33.hostinger.com.ua/phpmyadmin/index.php?db=u745861867_bd&token=316774a95ea556bc64cf7d398dd6aa83">База данных</a></td>

</tr>

</table>

</div>